from mis_game import *
from threading import Thread
import socket
from math import floor, sqrt

def clamp_and_bound(pos, dx, dy, bounds):
    if len(bounds) != 4:
        raise ValueError
        
    min_x = bounds[0]
    max_x = bounds[1]
    min_y = bounds[2]
    max_y = bounds[3]
    
    #should dx push the position out of bounds, reduce dx to push to *exactly* the bound
    if pos[0] + dx < min_x:
        dx = min(0,min_x - pos[0])
    elif pos[0] + dx > max_x:
        dx = min(0,max_x - pos[0])
        
    #should dy '         '
    if pos[1] + dy < min_y:
        dy = min(0,min_y - pos[1])
    elif pos[1] + dy > max_y:
        dy = min(0,max_y - pos[0])
        
    return (dx, dy)

def mloop(ref, me, others, mypos, myID):

    me.send(myID.to_bytes(4,'little',signed=True))
    #TODO: RATELIMIT SPEED OF LOOP TO 1/4 SECOND

    xspeed = 5
    yspeed = 5
    INV2 = 1 / sqrt(2) 

    while True:
        try:
            frame = me.recv(32)
        except socket.timeout:
            continue
         
        #extract
        dx = int.from_bytes(frame[:4] ,'little',signed=True)
        dy = int.from_bytes(frame[4:8],'little',signed=True)

        #calculate
        diag = 1 if not (dx and dy) else INV2
        dx_p = floor(xspeed * dx * diag)
        dy_p = floor(yspeed * dy * diag)
        dx_p, dy_p = clamp_and_bound(mypos,dx_p,dy_p,[-250,250,-250,250])
         
        #move
        mypos[0] += dx_p
        mypos[1] += dy_p
        
        #send back
        me.sendall( mypos[0].to_bytes(4,'little',signed=True) + mypos[1].to_bytes(4,'little',signed=True) +
                        dx_p.to_bytes(4,'little',signed=True) +     dy_p.to_bytes(4,'little',signed=True) +
                        myID.to_bytes(4,'little',signed=True)      
                  )
         
        #TODO: send back to every other
        for other in others:
            other.sendall( mypos[0].to_bytes(4,'little',signed=True) + mypos[1].to_bytes(4,'little',signed=True) +
                               dx_p.to_bytes(4,'little',signed=True) +     dy_p.to_bytes(4,'little',signed=True) +
                               myID.to_bytes(4,'little',signed=True)      
            )
        #other.sendall(frame)

class MIS_GAME:
    def __init__(self, socks):
        self.socks = socks
        self.poss = [[0,0] for sock in socks]
        self.threads = [Thread(target=mloop,args=(self, sock, list(filter(lambda x: x != sock, socks)),self.poss[idx],idx)) 
                        for idx, sock in enumerate(socks)]
        for t in self.threads:
            t.daemon = True
            t.start()