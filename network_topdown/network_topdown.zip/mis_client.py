import tkinter as tk
from tkinter import ttk
from math import floor, sqrt
from mis_util import *
import socket
from socket import AF_INET, SOCK_STREAM, IPPROTO_TCP, TCP_NODELAY
from socket import error as GENERIC_SOCKET_ERROR
from threading import Thread, Semaphore
import re
import time
import signal

cur_anim = 0 #for a pretty animation. Doubles as a polling timer
anims = ('|','/','—','\\')

def acquire_connection(): 
    global cur_anim, anims, myID
  
    #Request useer for server IP
    while True:
        serverName = input('Connect where? ')
        if not serverName:
            continue
        break

    serverPort = 9979

    #Establish a socket
    try:
        clientSocket = socket.socket(AF_INET, SOCK_STREAM)
        clientSocket.setsockopt(IPPROTO_TCP, TCP_NODELAY, 1)
        clientSocket.settimeout(0.5)
    except GENERIC_SOCKET_ERROR as e:
        print("Could not establish socket -",e)
        quit(1)
        
    #Connect the socket to the server
    try:
        clientSocket.connect((serverName,serverPort))
    except GENERIC_SOCKET_ERROR as e:
        print("Could not connect to server -",e)
        quit(1)
        
    while True: #wait for our 'all-clear'
        try:
            myID = int.from_bytes(clientSocket.recv(32),'little',signed=True)
            break
        except socket.timeout:
            cur_anim = (cur_anim + 1) % len(anims)
            print("\rWaiting for other player...", anims[cur_anim], end='')
            pass
        
    print("\r" + (" ") * 80)
    return clientSocket
    
def synchronize_in():
    global clientSocket, haveLatestPos, latest_pos, latest_dydx
    
    while True:
        try:
            frame = clientSocket.recv(64)
        except socket.timeout:
            continue
           
        x  = int.from_bytes(frame[  : 4],'little',signed=True)
        y  = int.from_bytes(frame[4 : 8],'little',signed=True)
        dx = int.from_bytes(frame[8 :12],'little',signed=True)
        dy = int.from_bytes(frame[12:16],'little',signed=True)
        iD = int.from_bytes(frame[16:20],'little',signed=True)
        latest_pos[iD]  = [x,y]
        latest_dydx[iD] = [dx,dy]
    
#send our position and dy/dx to the server
def synchronize_out(dx,dy):
    global clientSocket
    clientSocket.sendall( dx.to_bytes(4,'little',signed=True) + dy.to_bytes(4,'little',signed=True) )
    pass

def game_loop():
    global canv, keydowns, player_img
    global latest_pos, latest_dydx, haveLatestPos, myID
    global r
   
    #send current movement inputs
    dx = keydowns[2] - keydowns[0]
    dy = keydowns[3] - keydowns[1]
    synchronize_out(dx,dy)
    
    #calculate movement based off what the server gave us

    for iD, pos in latest_pos.items():
        canv.coords(imgs[iD], pos[0] - floor(r/2), pos[1]  - floor(r/2), 
                              pos[0] + floor(r/2), pos[1]  + floor(r/2))
        
        if iD == myID:
            canv.xview_moveto(0)
            canv.yview_moveto(0)
            canv.xview_scroll((300-250) + pos[0],tk.UNITS)
            canv.yview_scroll((300-250) + pos[1],tk.UNITS)

    canv.update()
    canv.after(25, game_loop)

def keyup(e):
    #print('up', e.keysym_num)
    k = e.keysym_num
    if k >= 65361 and k <= 65364: #arrow keys
        keydowns[k-65361] = 0
    
    
def keydown(e):
    #print('down', e.keysym_num)
    k = e.keysym_num
    if k >= 65361 and k <= 65364: #arrow keys
        keydowns[k-65361] = 1

if __name__ == "__main__":
    clientSocket = acquire_connection()

    #main window
    s_width,s_height = 500,500
    root = tk.Tk()
    ttk.Style(root).theme_use('alt')
    root.title("Shooter")
    root.resizable(False,False)
    root.geometry(str(s_width) + 'x' + str(s_height))
    
    root.bind("<KeyPress>", keydown)
    root.bind("<KeyRelease>", keyup)
    
    #canvas
    canv = tk.Canvas(root, bg='green', height=500, width=500, scrollregion=(-300,-300,300,300))
    canv["xscrollincrement"] = 1
    canv["yscrollincrement"] = 1
    #scroll the canvas to fit around our position '0,0' as the center
    canv.xview_scroll(-250, tk.UNITS)
    canv.yview_scroll(-250, tk.UNITS)
    canv.grid()

    #GAME VARIABLES
    
    #we'll just say 4 players for now. TODO: FIXME
    
    keydowns = [0]*4
    haveLatestPos = False
    latest_pos  = {n:[0, 0] for n in range(4)}
    latest_dydx = {n:[0, 0] for n in range(4)}
    
    #existent images
    canv.create_rectangle(-100,-100,-90,-90)
    canv.create_rectangle(90,100,100,90)
    
    canv.create_polygon([-250,-250,-250,250,250,250,250,-250],fill='',outline='black')
    
    #player image
    r = 50
    colors = ['black','cyan','red','orange']
    imgs = {n: canv.create_oval(-floor(r/2) - 1000, - floor(r/2), +floor(r/2) - 1000, +floor(r/2), outline=colors[n]) for n in range(4)}
    game_loop()
    
    
    in_recv = Thread(target=synchronize_in)
    in_recv.start()
    root.mainloop()