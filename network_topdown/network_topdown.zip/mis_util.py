def byte(i):
    return i.to_bytes(1,'little')